$('#carousel-1').carousel({
    interval: 4000,
    wrap: true,
    keyboard: true
});

$('#carousel-2').carousel({
    interval: 6000,
    wrap: true,
    keyboard: true
});